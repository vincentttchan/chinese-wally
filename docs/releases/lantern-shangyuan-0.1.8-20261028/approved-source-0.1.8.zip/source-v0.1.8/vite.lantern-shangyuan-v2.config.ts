import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({base:'/chinese-wally/',plugins:[react()],server:{host:'127.0.0.1',port:5217,strictPort:true},build:{outDir:'../build-0.1.8',copyPublicDir:false,cssMinify:false,rollupOptions:{input:'lantern-shangyuan-v2.html'}}});
