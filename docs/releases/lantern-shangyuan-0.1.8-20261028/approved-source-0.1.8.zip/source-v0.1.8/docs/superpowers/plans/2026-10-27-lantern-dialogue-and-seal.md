# 宮中鬧元宵獨立新版 Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** 交付可本機試玩的宮中三庭隨行與上元隨記獨立新版，不修改正式入口、不上線。

**Architecture:** 從本機可用的已部署來源 `efd4e22` 建立隔離 worktree；925檔保留紀錄確認宮中來源與入口封存部署一致。複製宮中遊戲外殼，新增版本專用對白、流程狀態、回望與蓋印，沿用唯讀共用原畫、介面與動畫。使用專用 Vite 入口及打包腳本產生獨立 HTML。

**Tech Stack:** React、TypeScript、Vite，既有原畫及篆體素材。

**Spec:** `docs/superpowers/specs/2026-10-27-lantern-dialogue-and-seal-design.md`（使用者2026-10-27確認定稿，授權獨立製作、暫不上線）。

## Global Constraints

- 現有封存版、正式路由、所有既有來源與公開素材均保持不變；只新增新版檔案。
- 三庭對白及收尾採定稿，主線觀察不自動補發支線收藏。
- 讀畢構圖回望才解鎖留印；預設「上元隨記」、一至四字、真篆體、沿用既有落印方式。
- 新流程與存檔獨立；既有收藏沿用讀取，試玩收藏寫入版本專用鍵，避免污染正式存檔。
- 不推送、不部署、不執行正式站打包腳本。
- 使用者 AGENTS.md 限定只記錄實際檢視、不自行增加未要求測試；不新增或跑測試套件，以本版型別／建置檢查及必要試玩路徑確認交付。

## Review Focus

- 回望未完成、關頁重入：回到已保存步驟，不能跳過構圖解說落印。
- 中文輸入法、缺字與清空：保持組字、一至四字、缺字提示及預設回復。
- 備印素材失敗或動畫中斷：可回畫中、重試、續留印。
- 已留印後重玩：保留印文與見聞，不讓玩家選了卻無法保存。
- 窄畫面：觀察熱區、對白、篆書印樣與落印按鈕保持可見可用。

---

### Task 1: 獨立入口與版本狀態

**Files:** 新增 `lantern-shangyuan-v2.html`、`src/lantern-shangyuan-v2.tsx`、`vite.lantern-shangyuan-v2.config.ts`、`src/game/lanternJourneyV2.ts`、`src/components/LanternShangyuanV2Game.tsx`。

**Interfaces:** 狀態模組提供三庭劇本、觀察位置、見聞選擇、獨立存檔載入／保存；新外殼保留原有探索與收藏操作，向新元件傳入進度更新及鏡頭命令。

- [x] 從部署來源複製遊戲外殼，新增獨立入口，不改正式路由。
- [x] 新狀態保存主線、對白、回望、草稿與最終印記，嚴格驗證載入資料。
- [x] 開場保留封面與三幕；重新入畫續接已保存流程，重玩保留印記。

### Task 2: 三庭對白與原畫觀察

**Files:** 新增 `src/components/LanternJourneyV2.tsx`、`src/lantern-shangyuan-v2.css`。

**Interfaces:** 消費狀態、viewport、onLook、onObserve／onNext；父層保存對白步驟，子層只管理當次鏡頭等待及演繹。

- [x] 實作逐句皇帝氣泡與玩家短回話。
- [x] 掩耳孩子原畫觀察；街市與輪上童子沿用動畫，失敗或略過回原畫可繼續。
- [x] 每次觀察後接定稿後半對白，完成才開下一庭。

### Task 3: 回望與上元隨記

**Files:** 新增 `src/components/LanternJourneyEndingV2.tsx`、`src/components/LanternJourneySealV2.tsx`。

**Interfaces:** 回望階段0–4後記錄mainComplete，選見聞、保存draft、落印成功保存seal；提供返回封面／自由探索／改選。

- [x] 三處回望與兩頁構圖旁白；讀畢後開放三選一見聞。
- [x] 以既有篆體／印框／印石實作冊末印樣、自訂四字、1.6秒落印及完成文案。
- [x] 見聞冊提供冊末入口，收藏分母保持8；可離開後續留印。
- [x] 失敗、減少動態、鍵盤及重玩走獨立分支。

### Task 4: 獨立成品與試玩

**Files:** 新增 `scripts/package-lantern-shangyuan-v2.mjs`、`public/chapters/lantern-shangyuan-v2-0.1.0/`、版本／交付文件。

- [x] 只執行本版 Vite 建置與封裝，不執行全站發布腳本。
- [x] 型別檢查；確認預設四字字形支援及所有素材引用。
- [x] 本機走入場、三庭、回望、選見聞、自訂留印、回封面／自由探索、重新進入；補看窄畫面及中斷續接。
- [x] 新鮮審閱代理檢查全版程式與定稿符合程度，處理實質問題。
- [x] 留下實際檢視紀錄、指紋與本機試玩網址；不宣稱未做的檢視。

## 執行紀錄

- 使用者已明確授權按定稿製作，直接執行，不再要求計畫重批。
- Baseline test suites omitted per user AGENTS.md; only targeted build and playability checks for this authorized independent deliverable.

- Task 1–4 complete: independent source snapshot used after native worktree checkout failed; existing clean deployed source was read only. No shared source edits.
- Verification: targeted TypeScript and Vite build succeeded; packaged HTML HTTP200; local browser actual flow through three courts, five review steps, selection, unsupported characters, default recovery, custom 山水知音 seal, booklet keyboard link, return to cover.
- Remaining unverified: physical mobile and Chinese IME composition, reduced-motion device setting, all eight side collections, post-stamp injected load failure and complete replay. No test suites run.
