import {lanternActors,lanternLocation,lanternTargets} from './lanternFestival.ts';
import {lanternFindings,loadLanternFindings,loadLanternFindingOrigins} from './lanternCollection.ts';
import type {LanternState} from './lanternState.ts';
import {lanternReducer} from './lanternState.ts';
import {journeySummaryComplete} from './lanternJourneySummary.ts';

export const journeyStorageKey='chinese-wally:lantern-shangyuan-v2-0.1.8:journey:v2';
export type JourneyProgress={phase:'searching'|'found'|'review'|'free';index:number;beat:number;review:number;answers:[number|null,number|null];memory:number|null;draft:string;seal:string|null;mainComplete:boolean};
export const initialJourney:JourneyProgress={phase:'searching',index:0,beat:0,review:0,answers:[null,null],memory:null,draft:'上元隨記',seal:null,mainComplete:false};
export function normalizeInscription(text:string){return Array.from(text.replace(/\s/gu,'')).slice(0,4).join('')||'上元隨記';}
export function loadJourney():JourneyProgress{
 try{
  const s=JSON.parse(localStorage.getItem(journeyStorageKey)||'null');
  if(!s||!['searching','found','review','free'].includes(s.phase))return {...initialJourney};
  const index=Number.isInteger(s.index)&&s.index>=0&&s.index<=2?s.index:0;
  const memory=Number.isInteger(s.memory)&&s.memory>=0&&s.memory<=2?s.memory:null;
  const answers:[number|null,number|null]=[0,1].map(i=>Array.isArray(s.answers)&&Number.isInteger(s.answers[i])&&s.answers[i]>=0&&s.answers[i]<=2?s.answers[i]:null) as [number|null,number|null];
  let review=Number.isInteger(s.review)&&s.review>=0&&s.review<=5?s.review:0;
  if(review>3&&answers[0]!==1)review=3;
  if(review>4&&!journeySummaryComplete(answers))review=4;
  const mainComplete=Boolean(s.mainComplete)&&review===5&&journeySummaryComplete(answers);
  const seal=mainComplete&&typeof s.seal==='string'&&s.seal.trim()?normalizeInscription(s.seal):null;
  const phase=s.phase==='free'&&!mainComplete?'review':s.phase;
  return {phase,index:phase==='review'||phase==='free'?2:index,beat:Number.isInteger(s.beat)&&s.beat>=0&&s.beat<=8?s.beat:0,review,answers,memory:mainComplete||seal?memory:null,draft:typeof s.draft==='string'?Array.from(s.draft).slice(0,16).join(''):initialJourney.draft,seal,mainComplete};
 }catch{return {...initialJourney};}
}
export function saveJourney(p:JourneyProgress){try{localStorage.setItem(journeyStorageKey,JSON.stringify(p));return true;}catch{return false;}}
export function journeyReducer(state:LanternState,action:Parameters<typeof lanternReducer>[1]|{type:'resume';saved:JourneyProgress}):LanternState{
 if(action.type==='resume'){
  const {phase,index}=action.saved;
  const count=phase==='searching'?index:phase==='found'?index+1:3;
  return {phase:phase==='review'||phase==='free'?'complete':phase,index,found:lanternTargets.slice(0,count).map(t=>t.id),help:0,wrong:false};
 }
 return lanternReducer(state,action);
}
// Read existing discoveries on first use, but all preview writes use independent keys.
const collectionKey='chinese-wally:lantern-shangyuan-v2-0.1.8:findings:v1';
const originsKey='chinese-wally:lantern-shangyuan-v2-0.1.8:origins:v2';
export function loadJourneyFindings():string[]{try{const s=localStorage.getItem(collectionKey);if(s===null)return loadLanternFindings();const ids=JSON.parse(s);return Array.isArray(ids)?ids.filter((id):id is string=>typeof id==='string'&&lanternFindings.some(f=>f.id===id)):[];}catch{return [];}}
export function saveJourneyFindings(ids:string[]){try{localStorage.setItem(collectionKey,JSON.stringify(ids));}catch{/* session remains usable */}}
export function loadJourneyOrigins():Record<string,string>{try{const s=localStorage.getItem(originsKey);if(s===null)return loadLanternFindingOrigins();const o=JSON.parse(s);return o&&typeof o==='object'&&!Array.isArray(o)?Object.fromEntries(Object.entries(o).filter(([key,v])=>lanternFindings.some(f=>f.id===key)&&typeof v==='string')) as Record<string,string>:{};}catch{return {};}}
export function saveJourneyOrigins(o:Record<string,string>){try{localStorage.setItem(originsKey,JSON.stringify(o));}catch{/* session remains usable */}}
export const journeyScripts=[
 ['來了？先別急着往前走，庭前正熱鬧呢。','奴婢方才只顧尋陛下，險些被爆竹嚇了一跳。','瞧那孩子，兩手捂住耳朵，還捨不得走遠。','看見了！旁邊的人正俯身引火，他便躲在一旁看。','有的搶着放，有的躲着看，各有各的樂趣。','這一庭的人，連看熱鬧的模樣也不一樣。','聽說前頭還擺起了街市，隨朕去看看。'],
 ['你也跟過來了。看看庭院裡，今日多了些甚麼？','有貨郎，還有擺滿小物的攤子。宮裡竟也做起買賣來了？','過元宵，把街市的熱鬧也搬進宮來。你瞧，孩子們早圍過去了。','各樣小物擺得滿滿的……難怪他們都往這邊來。','東西小，花樣倒不少。你方才只看着朕，可漏看了許多。','這回記住了。尋着陛下，也要看看陛下眼前的熱鬧。','前頭還有人獻藝，走，再去瞧瞧。'],
 ['來得正好。那輪上還站着一個孩子，你看見了嗎？','看見了！站得那樣高，手裡竟還拿着樂器。','再看看輪下，是誰托着他？','原來下面的人用腳托輪，上面的孩子站穩了，還要吹奏。','上下都得有本事，才能配合得好。','奴婢起初只看輪上的孩子，細看才知道，兩個人都忙着呢。','方才看爆竹，又逛街市，如今再看獻藝。這一路，你可記下了？','記下了。每到一庭，都有新的熱鬧。']
] as const;
export const journeyMemories=[
 {title:'爆竹庭前',body:'有人俯身引火，有人掩耳躲看，同一庭裡，各有各的熱鬧。',crop:{image:lanternTargets[0].detail.image,sourceWidth:1296,rect:[140,870,660,490] as const}},
 {title:'宮中街市',body:'貨郎把各樣小物帶進宮苑，童子圍看，街市也成了元宵的一景。',crop:lanternFindings.find(f=>f.id==='market')!.crop},
 {title:'上下獻藝',body:'輪下的人用腳托輪，輪上的孩子站立吹奏，一場好戲靠兩人配合。',crop:lanternFindings.find(f=>f.id==='acrobat')!.crop}
];
export const journeyChild=lanternActors.find(a=>a.id==='court-one-11')!;
export const journeyChildFocus=lanternLocation(9,490,1110);
export const journeyChildRegion={points:[{x:journeyChild.x-journeyChild.width/2,y:journeyChild.y-journeyChild.height/2},{x:journeyChild.x+journeyChild.width/2,y:journeyChild.y-journeyChild.height/2},{x:journeyChild.x+journeyChild.width/2,y:journeyChild.y+journeyChild.height/2},{x:journeyChild.x-journeyChild.width/2,y:journeyChild.y+journeyChild.height/2}]};
