import type {SceneHitResolver} from '../components/ScrollScene.tsx';
export const isJourneyLamp=(id:string)=>id==='finding-standing-lamp'||id.startsWith('finding-lamp-');
export const lanternJourneyHit:SceneHitResolver=(world,scale,size,actors)=>{
 const contains=(a:typeof actors[number],padded:boolean)=>{
  const dx=Math.abs(world.x-a.x*size.width),dy=Math.abs(world.y-a.y*size.height);
  if(isJourneyLamp(a.id))return !padded&&dx<=a.width*size.width*.425&&dy<=a.height*size.height*.425;
  return dx<=Math.max(a.width*size.width,padded?44/scale:0)/2&&dy<=Math.max(a.height*size.height,padded?44/scale:0)/2;
 };
 const painted=actors.filter(a=>contains(a,false));
 return (painted.length?painted:actors.filter(a=>contains(a,true))).sort((a,b)=>{
  const fish=(id:string)=>id==='finding-fish'?1:0;
  return fish(b.id)-fish(a.id)||Math.hypot(world.x-a.x*size.width,world.y-a.y*size.height)-Math.hypot(world.x-b.x*size.width,world.y-b.y*size.height);
 })[0]??null;
};
