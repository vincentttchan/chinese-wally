const pending=new Map<string,Promise<HTMLImageElement>>();
export function prepareAnimationImages(sources:readonly string[]){
 return Promise.all(sources.map(src=>{
  let task=pending.get(src);
  if(!task){task=new Promise<HTMLImageElement>((resolve,reject)=>{
   const image=new Image();image.onload=()=>{image.decode().then(()=>resolve(image),reject);};image.onerror=()=>reject(new Error('Animation image unavailable'));image.src=src;
  });pending.set(src,task);task.catch(()=>{if(pending.get(src)===task)pending.delete(src);});}
  return task;
 }));
}
