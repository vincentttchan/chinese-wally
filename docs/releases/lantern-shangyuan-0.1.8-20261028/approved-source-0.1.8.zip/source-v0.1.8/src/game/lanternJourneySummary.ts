export const journeySummaryQuestions=[
 {title:'同一位皇帝，為甚麼出現三次？',prompt:'回想三庭中，他的面孔、姿勢和眼前的活動。這三次身影有甚麼關係？',choices:['三位不同的皇帝，一起過元宵','同一位皇帝，先後參與不同活動','同一個瞬間，從三個方向畫他'],correct:1,hint:'再想想：面孔相同，姿勢與眼前的活動卻變了。',explanation:'是同一位明憲宗。他先看爆竹，再看街市，最後觀看獻藝。畫家讓他在不同庭院再次出現，把不同時刻串在同一幅畫裡；這是「連環畫式構圖」。'},
 {title:'畫中的熱鬧，讓你看見甚麼？',prompt:'從爆竹、貨郎擔到庭院獻藝，這幅畫留下了怎樣的元宵見聞？',choices:['宮廷安排多種節慶活動，眾人一起參與','百姓平日街市生活的完整實錄','只有皇帝觀燈，旁人只是陪襯'],correct:0,hint:'再看看三庭裡的人：有人引火、有人圍看小物，也有人配合獻藝。這些活動發生在哪裡？',explanation:'爆竹、仿設街市與獻藝，把宮中的元宵畫得熱鬧。畫家細畫每個人的動作與反應，又用皇帝的三次身影串起活動。這是宮廷安排的節慶盛景；了解百姓日常，還需要其他史料。'}
] as const;
export const journeySummaryComplete=(answers:readonly (number|null)[])=>journeySummaryQuestions.every((q,i)=>answers[i]===q.correct);
