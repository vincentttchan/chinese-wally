import {StrictMode, useEffect, useState} from 'react';
import {createRoot} from 'react-dom/client';
import {LanternShangyuanV2Game} from './components/LanternShangyuanV2Game.tsx';
import {assetPath} from './game/assets.ts';
import './styles-lantern-v2.css';
import './page-motion.css';
import './page-motion-lantern-v2.js';

function VersionedChapter() {
  const [revision,setRevision]=useState(0);
  useEffect(()=>{
    const cover=()=>setRevision(value=>value+1);
    const navigate=()=>{
      const hash=window.location.hash;
      if(hash && hash!=='#lantern-festival')window.location.assign(`https://vincentttchan.github.io/chinese-wally/${hash}`);
    };
    window.addEventListener('chapter-cover',cover);
    window.addEventListener('hashchange',navigate);
    navigate();
    return()=>{window.removeEventListener('chapter-cover',cover);window.removeEventListener('hashchange',navigate);};
  },[]);
  return <LanternShangyuanV2Game key={revision}/>;
}

createRoot(document.getElementById('root')!).render(<StrictMode><VersionedChapter/></StrictMode>);
