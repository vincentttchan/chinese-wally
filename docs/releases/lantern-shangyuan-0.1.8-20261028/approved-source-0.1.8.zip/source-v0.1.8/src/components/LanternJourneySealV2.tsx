import {useEffect,useId,useMemo,useRef,useState} from 'react';
import {useChapterFocus} from './ChapterDialog.tsx';
import {assetPath} from '../game/assets.ts';
import {zanhuaSealCharacters} from '../game/zanhuaSealCharacters.ts';
import {normalizeInscription} from '../game/lanternJourneyV2.ts';
import type {JourneyProgress} from '../game/lanternJourneyV2.ts';
import type {SceneViewport} from './ScrollScene.tsx';
import {lanternLocation,lanternSize} from '../game/lanternFestival.ts';
export const journeySealPoint=lanternLocation(5,350,880);
function sealPosition(viewport:SceneViewport){
 const {view}=viewport,p=journeySealPoint;
 return {left:view.x+p.x*lanternSize.width*view.scale,top:view.y+p.y*lanternSize.height*view.scale,width:Math.max(54,120*p.scale*view.scale)};
}
export function JourneyPlayerSeal({viewport,text}:{viewport:SceneViewport;text:string}){
 const position=sealPosition(viewport);
 const [fontReady,setFontReady]=useState(false);
 useEffect(()=>{let live=true;void loadSealFont().then(()=>{if(live)setFontReady(true);}).catch(()=>{});return()=>{live=false;};},[]);
 if(!fontReady)return null;
 return <div className="journey-player-seal" style={{...position,height:position.width}} role="img" aria-label={`我的觀遊紀念印：${text}（遊戲新增）`}><JourneySealFace text={text}/></div>;
}
const sealArt={impression:assetPath('art/zanhua/seal/collector-frame-v3.png'),stone:assetPath('art/zanhua/seal/scholar-stone-v1.png')};
const sealFontFamily='Lantern Journey Chong Xi Seal';
let sealFontTask:Promise<void>|null=null;
function loadSealFont(){
 if(!sealFontTask)sealFontTask=new FontFace(sealFontFamily,`url("${assetPath('chapters/lantern-shangyuan-v2-0.1.8/fonts/chongxi/chongxi_seal.otf')}") format("opentype")`).load().then(font=>{document.fonts.add(font);}).catch(error=>{sealFontTask=null;throw error;});
 return sealFontTask;
}

/** Typeset every inscription in the same actual small-seal font, read down the right column first. */
export function JourneySealFace({text}:{text:string}){
 const grain=useId();
 const glyphs=useMemo(()=>{
  const context=document.createElement('canvas').getContext('2d')!;
  context.font=`100px "${sealFontFamily}"`;
  return Array.from(text).map(char=>{
   const m=context.measureText(char);
   return {char,box:`${-m.actualBoundingBoxLeft} ${-m.actualBoundingBoxAscent} ${m.actualBoundingBoxLeft+m.actualBoundingBoxRight} ${m.actualBoundingBoxAscent+m.actualBoundingBoxDescent}`};
  });
 },[text]);
 const cells=glyphs.length===1?[[12,10,76,80]]:glyphs.length===2?[[53,10,37,80],[10,10,37,80]]:glyphs.length===3?[[53,10,37,80],[10,10,37,37],[10,53,37,37]]:[[53,10,37,37],[53,53,37,37],[10,10,37,37],[10,53,37,37]];
 return <svg className="journey-seal-face" viewBox="0 0 100 100" aria-hidden="true">
  <defs><filter id={grain} x="0" y="0" width="100%" height="100%"><feTurbulence type="fractalNoise" baseFrequency="1.3" numOctaves="3" seed="17" result="noise"/><feColorMatrix in="noise" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  3 3 3 0 -3.6" result="wear"/><feComposite in="SourceGraphic" in2="wear" operator="in"/></filter></defs>
  <image href={sealArt.impression} x="-5" y="-5" width="110" height="110"/>
  <g fill="#b34539" filter={`url(#${grain})`}>{glyphs.map((glyph,n)=>{
   const [x,y,width,height]=cells[n];
   return <svg key={n} x={x} y={y} width={width} height={height} viewBox={glyph.box} preserveAspectRatio="none"><text x="0" y="0" fontFamily={sealFontFamily} fontSize="100">{glyph.char}</text></svg>;
  })}</g>
 </svg>;
}


export function LanternJourneySealV2({progress,onChange,onClose,onCover,onExplore,viewport}:{progress:JourneyProgress;onChange:(patch:Partial<JourneyProgress>)=>void;onClose:()=>void;onCover:()=>void;onExplore:()=>void;viewport:SceneViewport}){
 const [ready,setReady]=useState(false),[failed,setFailed]=useState(false),[attempt,setAttempt]=useState(0),[pressed,setPressed]=useState<string|null>(null),[composing,setComposing]=useState(false);
 const root=useRef<HTMLDivElement>(null),button=useRef<HTMLButtonElement>(null),field=useId();
 const change=useRef(onChange);change.current=onChange;
 const text=normalizeInscription(progress.draft),done=Boolean(progress.seal),pressing=Boolean(pressed)&&!done;
 const position=sealPosition(viewport);
 const missing=Array.from(text).filter(char=>!zanhuaSealCharacters.has(char));
 const invalid=missing.length>0;
 
 useChapterFocus(root,true,()=>{if(!pressing)onClose();});
 useEffect(()=>{
  let live=true;setReady(false);setFailed(false);
  const timeout=window.setTimeout(()=>{if(live){setFailed(true);}},18000);
  Promise.all([loadSealFont(),...Object.values(sealArt).map(src=>new Promise<void>((resolve,reject)=>{const im=new Image();im.onload=()=>resolve();im.onerror=reject;im.src=src;}))]).then(()=>{if(live){clearTimeout(timeout);setReady(true);setFailed(false);}},()=>{if(live){clearTimeout(timeout);setFailed(true);}});
  return()=>{live=false;clearTimeout(timeout);};
 },[attempt]);
 useEffect(()=>{
  if(!pressed||done)return;
  const timer=window.setTimeout(()=>change.current({seal:pressed,phase:'free'}),matchMedia('(prefers-reduced-motion: reduce)').matches?0:1600);
  return()=>clearTimeout(timer);
 },[pressed,done]);
 useEffect(()=>{if(ready)button.current?.focus({preventScroll:true});},[ready,done]);
 const stamp=()=>{if(ready&&!failed&&!invalid&&!composing&&!pressed&&!done){onChange({draft:text});setPressed(text);}};
 return <div ref={root} className="journey-seal-layer" tabIndex={-1} role="dialog" aria-modal="true" aria-label="上元隨記・觀遊留印" style={{'--seal-frame-height':`${viewport.frame.height}px`} as import('react').CSSProperties}>
 <div className="journey-scroll-seal" style={{...position,top:position.top-position.width/2}} aria-label="畫卷旁留印處">
  {ready&&<button className={`journey-seal-target ${done?'is-stamped':''} ${pressing?'is-pressing':''}`} disabled={done||pressing||invalid||composing} aria-label={done?`我的觀遊紀念印：${progress.seal}`:`在畫卷旁蓋下「${text}」印章`} onClick={stamp}><JourneySealFace text={done?progress.seal!:invalid?'上元隨記':text}/></button>}
  {pressing&&<img className="journey-stamp-tool" src={sealArt.stone} alt=""/>}
  {ready&&!done&&!pressing&&<span className="lantern-note-caption">輕點朱印虛影，即可落印</span>}
  {done&&<span className="lantern-note-caption">「{progress.seal}」 · 觀遊紀念</span>}
 </div>
 <section className="lantern-observation-note journey-seal-note" aria-label="觀遊留印">
  <p className="lantern-observation-eyebrow">三庭隨行 · 觀遊留印</p>
  <h2>{done?'《宮中鬧元宵》遊歷完成':'把這次遊歷，留在卷旁'}</h2>
  <p className="lantern-note-body" role="status">{failed?'印章素材暫未載入，請再試一次。':!ready?'正在備印':pressing?'落印，稍停，再輕輕提起。':done?'三次身影，串起一卷元宵。\n這方朱印，記下你曾在畫中停留。':'你已隨着同一位皇帝，走過三庭熱鬧。\n爆竹、街市與獻藝，也在長卷中連成了一段元宵行樂。'}</p>
  {!done&&<>
   <p className="lantern-note-caption">在畫卷旁的留印處，蓋下屬於你的觀遊紀念印。</p>
   <label className="journey-seal-field" htmlFor={field}>我的印文 <input id={field} tabIndex={0} value={progress.draft} disabled={!ready||pressing} onCompositionStart={()=>setComposing(true)} onCompositionEnd={e=>{setComposing(false);onChange({draft:Array.from(e.currentTarget.value.replace(/\s/gu,'')).slice(0,4).join('')});}} onChange={e=>onChange({draft:composing?e.target.value:Array.from(e.target.value.replace(/\s/gu,'')).slice(0,4).join('')})} onBlur={()=>{if(!composing)onChange({draft:text});}} aria-invalid={invalid} aria-describedby={invalid?`${field}-error`:undefined} placeholder="上元隨記" autoComplete="off"/><span>至多四字</span></label>
   {ready&&<div className="journey-seal-proof"><div role="img" aria-label={`篆書印樣：${invalid?'上元隨記':text}`}><JourneySealFace text={invalid?'上元隨記':text}/></div><p>篆書印樣<span>自右向左，從上往下讀</span></p></div>}
   {invalid&&<p id={`${field}-error`} className="journey-seal-error" role="status">「{[...new Set(missing)].join('、')}」暫無此篆體字形，請換一字再落印。 <button className="lantern-text-button" disabled={pressing} onClick={()=>onChange({draft:'上元隨記'})}>使用上元隨記</button></p>}
  </>}
  <p className="lantern-note-caption">{!done&&<>印位在朱印虛影處，輕點即可落印。<br/></>}此印為遊戲觀遊紀念。</p>
  <a className="journey-font-credit" href="https://xiaoxue.iis.sinica.edu.tw/chongxi/" target="_blank" rel="noreferrer">篆字：崇羲篆體 · 王心怡等製作</a>
  {done&&failed&&<button className="lantern-note-next" onClick={()=>setAttempt(a=>a+1)}>重新備印 →</button>}
  {done?<><button ref={button} className="lantern-note-next" onClick={onCover}>回到本章封面 →</button><button className="lantern-text-button" onClick={onExplore}>留在畫中自由探索 →</button></>:<>
   {failed?<button className="lantern-note-next" onClick={()=>setAttempt(a=>a+1)}>重新備印 →</button>:<button ref={button} className="lantern-note-next" disabled={!ready||invalid||pressing||composing} onClick={stamp}>{pressing?'正在落印':ready?'蓋下我的印章':'正在備印'} →</button>}
   <button className="lantern-text-button" disabled={pressing} onClick={onClose}>先回畫中，稍後留印</button>
  </>}
 </section>
 </div>;
}
