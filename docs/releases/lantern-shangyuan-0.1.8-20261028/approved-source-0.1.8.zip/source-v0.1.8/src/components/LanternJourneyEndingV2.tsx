import {useEffect,useRef,useState} from 'react';
import {LanternPaintingNote} from './LanternPaintingNote.tsx';
import {LanternJourneySealV2,journeySealPoint} from './LanternJourneySealV2.tsx';
import {journeySummaryQuestions} from '../game/lanternJourneySummary.ts';
import type {JourneyProgress} from '../game/lanternJourneyV2.ts';
import {lanternReviewCommand} from './lanternReviewCommand.ts';
import type {SceneViewport,StudyCommand} from './ScrollScene.tsx';
import {useChapterFocus} from './ChapterDialog.tsx';

type Props={progress:JourneyProgress;viewport:SceneViewport;onChange:(p:Partial<JourneyProgress>)=>void;onFrame:(command:StudyCommand)=>void;onClose:()=>void;onCover:()=>void};
const captions=['黃幔下，他坐着看爆竹。','石台旁，他站着看街市。','帳幔中，他又坐下看獻藝。'];
export function LanternJourneyEndingV2({progress:p,viewport,onChange,onFrame,onClose,onCover}:Props){
 const [busy,setBusy]=useState(true);
 const [selected,setSelected]=useState<[number|null,number|null]>(()=>[...p.answers]);
 const root=useRef<HTMLDivElement>(null),note=useRef<HTMLElement>(null),frame=useRef(onFrame);frame.current=onFrame;
 const sealStage=p.mainComplete;
 const compact=viewport.frame.width<700,scene=Math.min(p.review,2);
 useChapterFocus(root,!sealStage,()=>{});
 useEffect(()=>{
  let live=true;setBusy(true);
  const command=lanternReviewCommand(scene,'scene',viewport.frame,'pan',()=>{if(live){setBusy(false);note.current?.focus({preventScroll:true});}});
  if(sealStage){command.region=journeySealPoint;command.screenAnchor=compact?{x:.5,y:.2}:{x:.25,y:.65};command.scaleRatio=compact?1.05:.95;}
  frame.current(command);
  return()=>{live=false;};
 },[scene,compact,sealStage]);
 useEffect(()=>{if(!busy&&note.current){note.current.scrollTop=0;note.current.focus({preventScroll:true});}},[p.review,busy,p.answers[0],p.answers[1]]);
 if(sealStage)return <LanternJourneySealV2 progress={p} onChange={onChange} onClose={onClose} onCover={onCover} onExplore={onClose} viewport={viewport}/>;
 const quiz=p.review===3||p.review===4;
 const question=journeySummaryQuestions[p.review===4?1:0],answer=p.answers[p.review===4?1:0],correct=answer===question.correct;
 const questionIndex=p.review===4?1:0;
 const pending=selected[questionIndex];
 const choose=(value:number)=>{
  const next:[number|null,number|null]=[...selected];next[questionIndex]=value;setSelected(next);
  const answers:[number|null,number|null]=[...p.answers];answers[questionIndex]=null;onChange({answers});
 };
 const confirm=()=>{if(pending===null)return;const answers:[number|null,number|null]=[...p.answers];answers[questionIndex]=pending;onChange({answers});};
 const explaining=quiz&&answer!==null;
 const retry=()=>{const answers:[number|null,number|null]=[...p.answers];answers[questionIndex]=null;onChange({answers});};
 const title=p.review<3?'三庭之間，他的身影':explaining?(correct?(questionIndex===0?'一卷之中，串起不同時刻':'宮中的元宵盛景'):'再看一看畫中線索'):question.title;
 return <div ref={root} tabIndex={-1} className={`lantern-inpainting-review journey-review ${quiz?'journey-quiz':''} ${explaining?'journey-explanation':''}`} aria-label="畫中回望與總結">
 <LanternPaintingNote index={scene} viewport={viewport} label={p.review<3?'畫中回望':quiz?`畫中一問 · ${p.review-2} / 2${explaining?' · 說明':''}`:'上元隨記'} title={title} busy={busy} noteRef={note}>
  {p.review<3?<><p className="lantern-note-body">{captions[p.review]}</p><button className="lantern-note-next" onClick={()=>onChange({review:p.review+1})}>看下一處 →</button></>:quiz?<>
   {explaining?<>
    <p className="lantern-note-body">{correct?question.explanation:question.hint}</p>
    {correct?<button className="lantern-note-next" onClick={()=>onChange(p.review===4?{review:5,mainComplete:true}:{review:4})}>{p.review===3?'看下一題':'觀遊留印'} →</button>:<button className="lantern-note-next" onClick={retry}>返回重新作答 →</button>}
   </>:<>
    <p className="lantern-note-body">{question.prompt}</p>
    <div className="lantern-note-choices" role="group" aria-label={question.title}>{question.choices.map((text,i)=><button key={text} aria-pressed={pending===i} onClick={()=>choose(i)}>{text}</button>)}</div>
    <button className="lantern-note-next" disabled={pending===null} onClick={confirm}>確認答案 →</button>
   </>}
  </>:null}
 </LanternPaintingNote>
 </div>;
}
