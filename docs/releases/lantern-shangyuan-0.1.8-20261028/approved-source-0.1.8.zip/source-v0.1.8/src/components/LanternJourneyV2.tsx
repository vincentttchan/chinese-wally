import {useEffect,useRef,useState} from 'react';
import {journeyScripts,journeyChildRegion,journeyChildFocus} from '../game/lanternJourneyV2.ts';
import {lanternActors,lanternTargets} from '../game/lanternFestival.ts';
import {LanternEmperorSpeech} from './LanternEmperorSpeech.tsx';
import {LanternPaintingNote} from './LanternPaintingNote.tsx';
import {LanternPaintingTarget} from './LanternPaintingTarget.tsx';
import {LanternMarketAnimation,lanternMarketRegion,lanternMarketFocus,preloadLanternMarket} from './LanternMarketAnimation.tsx';
import {LanternAcrobatAnimation,lanternAcrobatRegion,lanternAcrobatFocus} from './LanternAcrobatAnimation.tsx';
import type {SceneViewport,StudyCommand} from './ScrollScene.tsx';
import '../lantern-observation.css';

type Props={index:number;beat:number;viewport:SceneViewport;onBeat:(beat:number)=>void;onNext:()=>void;onFrame:(command:StudyCommand)=>void};
const actions=['看看掩耳的孩子','看看貨郎的小物','看看輪上與輪下'];
const prompts=['找找兩手捂住耳朵的孩子，再看看附近誰正俯身引火。','看看貨郎擔與圍看的童子，找找擔上有哪些小物。','看看輪上的童子，再看看輪下的人怎樣把輪托起。'];
const nextLabels=['循着街市的熱鬧，再尋他的身影','往獻藝的庭院，再尋他的身影','回望這一卷的元宵'];
function wrapLine(text:string){
 if(text.length<24)return text;
 const breaks=Array.from(text).flatMap((char,i)=>'，。？！'.includes(char)&&i>4&&i<text.length-5?[i+1]:[]);
 const at=breaks.sort((a,b)=>Math.abs(a-text.length/2)-Math.abs(b-text.length/2))[0];
 return at?text.slice(0,at)+'\n'+text.slice(at):text;
}
export function LanternJourneyV2({index,beat,viewport,onBeat,onNext,onFrame}:Props){
 const [busy,setBusy]=useState(true),[playing,setPlaying]=useState(false),[issue,setIssue]=useState(false);
 const note=useRef<HTMLElement>(null),live=useRef(true),frame=useRef(onFrame);frame.current=onFrame;
 useEffect(()=>{if(index===1)void preloadLanternMarket().catch(()=>{});},[index]);
 const compact=viewport.frame.width<700;
 const observing=beat===3;
 const detailView=observing||beat===4;
 useEffect(()=>{
  live.current=true;setBusy(true);
  const actor=lanternActors.find(a=>a.id===lanternTargets[index].id)!;
  const focus=detailView?(index===0?journeyChildFocus:index===1?lanternMarketFocus:lanternAcrobatFocus):{x:actor.x,y:actor.y};
  frame.current({region:focus,scaleRatio:detailView?(compact?1.05:1.25):(compact?1.65:1.4),screenAnchor:compact?{x:.5,y:.25}:{x:.68,y:.43},transition:'pan',token:performance.now(),onSettled:()=>{if(live.current){setBusy(false);note.current?.focus({preventScroll:true});}}});
  return()=>{live.current=false;};
 },[index,detailView,compact]);
 const script=journeyScripts[index];
 const line=observing?0:beat>3?beat-1:beat;
 const text=script[Math.min(line,script.length-1)];
 const player=line===1||line===3||line===5||(index===2&&line===7);
 const finish=()=>{setPlaying(false);onBeat(4);};
 const observe=()=>{
  if(index===0||matchMedia('(prefers-reduced-motion: reduce)').matches){finish();return;}
  setPlaying(true);setIssue(false);
 };
 if(busy)return <span className="sr-only" role="status">正在移近原畫</span>;
 if(observing)return <>
  {!playing&&<LanternPaintingTarget region={index===0?journeyChildRegion:index===1?lanternMarketRegion:lanternAcrobatRegion} viewport={viewport} label={actions[index]} hint="輕點畫中人物" onClick={observe}/>}
  {!playing&&<LanternPaintingNote index={index} viewport={viewport} label={`隨行見聞 · ${index+1} / 3`} title={actions[index]} noteRef={note}><p className="lantern-note-body">{prompts[index]}</p><p className="lantern-note-caption">輕點原畫中的人物或物件，細看這一刻。</p></LanternPaintingNote>}
  {playing&&index===1&&<LanternMarketAnimation viewport={viewport} onDone={finish} onError={()=>{setIssue(true);finish();}}/>}
  {playing&&index===2&&<LanternAcrobatAnimation viewport={viewport} onDone={finish} onError={()=>{setIssue(true);finish();}}/>}
  {playing&&<button className="lantern-quiet-button journey-skip" onClick={finish}>略過演繹，細看原畫 →</button>}
 </>;
 const last=line===script.length-1;
 const advance=()=>last?onNext():onBeat(beat+1);
 if(player)return <section ref={note} tabIndex={-1} className="lantern-observation-note journey-player-reply" aria-label="你・小內侍的遊戲虛構對白"><p className="lantern-observation-eyebrow">你・小內侍</p><p className="lantern-note-body" role="status">{text}</p>{issue&&<p className="lantern-note-caption">演繹暫未載入，仍可細看原畫。</p>}<button className="lantern-note-next" onClick={advance}>{last?nextLabels[index]:'繼續'}<span aria-hidden="true"> →</span></button></section>;
 return <LanternEmperorSpeech actor={lanternActors.find(a=>a.id===lanternTargets[index].id)!} viewport={viewport} text={wrapLine(text)} actionLabel={last?nextLabels[index]:beat===2?actions[index]:'繼續'} onContinue={advance}/>;
}
